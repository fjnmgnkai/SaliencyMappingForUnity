#----------------------------------------------------------
#スクリプト要約
#Unityで撮影したスクリーンショットをサリエンシー解析する。
#----------------------------------------------------------

#!/usr/bin/env python
# coding: utf-8

import cv2
import numpy as np
import os
import shutil
import argparse
from datetime import datetime
from pathlib import Path

# 引数で親フォルダパスを受け取る
parser = argparse.ArgumentParser()
parser.add_argument('--root', type=str, required=True, help="SaliencyMappingForUnity の親フォルダパス")
args = parser.parse_args()


#フォルダ構築

#----------標準ディレクトリ構造----------
#rootFloder(Unity側で設定した親フォルダパス)
# └SaliencyMappingForUnity
#   └input
#     └BK
#     └(スクショ画像).png
#   └output
#     └BK
#     └latest.png
#   └Script
#     └SaliencyViewer.py

base_dir = Path(args.root) / "SaliencyMappingForUnity"
input_dir = base_dir / "input"
output_dir = base_dir / "output"
bk_output_dir = output_dir / "BK"
#最新画像を常に表示するために、latest.pngに名前を変更している。BKフォルダに退避できない場合、正常に動かなくなるため念のためフォルダを追加
bk_output_dir.mkdir(exist_ok=True) 

# 出力ファイル退避
# 前回出力したファイルをBKに移動　
files = list(output_dir.glob("*.png"))
if files:
    file = files[0]
    new_name = file.stem + "_" + datetime.now().strftime("%Y%m%d%H%M%S") + file.suffix
    shutil.move(str(file), str(bk_output_dir / new_name))

# 最新入力画像読み込み
files = sorted(input_dir.glob("*.png"), key=os.path.getmtime)
if not files:
    exit()

file = files[0]

#-----------------------------------------------------------------------------------------------------------
#compute_saliency() 要約 : サリエンシー解析
#----------------------------------------------------------
#機能
#①解析画像読み込み・変換
#②サリエンシー要素への変換
#③重みづけ
#④画像出力
#----------------------------------------------------------
def compute_saliency(img):

    #解析画像変換 幅・高さ取得⇒グレースケール変換
    h, w = img.shape[:2]
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    #OenCVのサリエンシーを使用
    fg = cv2.saliency.StaticSaliencyFineGrained_create()
    _, sal_fg = fg.computeSaliency(img)
    sal_fg = (sal_fg * 255).astype(np.uint8)

    #ラプラシアンフィルタでコントラスト差取得
    contrast = cv2.Laplacian(gray, cv2.CV_64F)
    contrast = np.abs(contrast)
    contrast = (contrast / contrast.max() * 255).astype(np.uint8)

    #画面中心重みづけ
    yy, xx = np.meshgrid(np.linspace(-1, 1, w), np.linspace(-1, 1, h))
    gauss = np.exp(-(xx**2 + yy**2) * 5)
    gauss = (gauss / gauss.max() * 255).astype(np.uint8)

    #色彩取得
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    hue = hsv[:, :, 0].astype(np.float32)
    hue_diff = cv2.Laplacian(hue, cv2.CV_32F)
    hue_map = np.abs(hue_diff)
    hue_map = (hue_map / hue_map.max() * 255).astype(np.uint8)

    #重みづけ合成
    #OpenCVサリエンシー...目立ちやすさを総合的に判定しており、ベースとして活用。
    #　			　統計的に推定するだけであり、他の部分で補強する必要があるため0.4
    #コントラスト差...コントラスト差の高いエリアが最も早く認識される。
    #		　　　補強部分のうち、大部分を占めるべきであるため、0.3
    #色彩差...色彩差もフォーカルポイントの判定に役立つが、背景などの文脈依存になりがちである。
    #　　　　 強く依存しすぎると誤検出・正しい結果が得られなくなるため、0.2
    #中心重みづけ...心理学として画面中心への注視傾向を考慮。補助の補助として活用するため、0.1。

    combined = (
        0.4 * sal_fg +
        0.3 * contrast +
        0.2 * hue_map +
        0.1 * gauss
    )

    #合成結果を正規化
    combined = ((combined - combined.min()) / (combined.max() - combined.min()) * 255).astype(np.uint8)

    #ヒートマップ生成
    heatmap = cv2.applyColorMap(combined, cv2.COLORMAP_JET)
    return cv2.addWeighted(img, 0.6, heatmap, 0.5, 1.0)
#-----------------------------------------------------------------------------------------------------------

#画像格納
img = cv2.imread(str(file))
if img is None:
    print(f"読み込み失敗: {file}")
    exit()

result = compute_saliency(img)
if result is not None:
    saliency_path = output_dir / f"saliency_{file.name}"
    cv2.imwrite(str(saliency_path), result)

    latest_path = output_dir / "latest.png"
    try:
        os.rename(saliency_path, latest_path)
    except Exception as e:
        print(f"リネーム失敗: {e}")

    # 入力画像退避
    bk_input = input_dir / "BK"
    bk_input.mkdir(exist_ok=True)
    shutil.move(str(file), bk_input)

    #print("latest.png 出力")
